const {MessageEmbed} = require('discord.js');
const {color, frases} = require('../config/json/config.json');
module.exports = (client) => {
client.on('guildMemberAdd', async (member) => {
    

const peaceHolders = {  
    '{member}': member.user.username,    '{@member}': member.user.toString(),   
    '{guild}': member.guild.name,   
    '{guild.id}': member.guild.id,   
    '{memberCount}': member.guild.members.cache.filter(m => m.user.bot !== true).size,    
    '{botCount}': member.guild.members.cache.filter(m => m.user.bot !== false).size    
}
  const peaceReq = new RegExp(Object.keys(peaceHolders).join('|'), 'ig')

    let channel = await client.db.get(`welcome-${member.guild.id}`)
    
    if(channel === null) return;
    
    const embed = new MessageEmbed()
    .setTitle(`**Bem vindo**`)
 .setDescription(frases.welcome.replace(peaceReq, match => peaceHolders[match]))
    
    client.channels.cache.get(channel).send({embed})
    });
}