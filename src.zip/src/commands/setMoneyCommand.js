const user = require('../mongoDB/user.js');
exports.run = async (client, message, args) => {
    if(!['392087996821667841'].includes(message.author.id)) return;
let amount = args[1];
    if(!amount) return message.inlineReply(`Coloque um número para setar`)
    if(isNaN(amount)) return message.inlineReply(`Coloque um número válido`)
        let member = message.mentions.users.first()

    if(!isNaN(args[0])) {

        member = await client.users.fetch(String(args[0]))
    }
        if(!member) return message.inlineReply(`Mencione ou coloque o ID do usuário`)
        
        let dataUser = await user.findOne({ User: member.id })
        
        if(!dataUser) return message.inlineReply(`O usuário <@!${member.id}>(\`${member.tag}/${member.id}\`) não está registrado na database`)
   
    await user.findOneAndUpdate({User: member.id}, {$set: {
        Daily: dataUser.Daily + Number(amount)
    }})
 
    message.inlineReply(`Você setou ${amount} créditos para <@!${member.id}>(\`${member.tag}/${member.id}\`)`)
}
exports.config = {
    name: "setmoney",
    aliases: ['addmoney']
    }