const {MessageEmbed} = require('discord.js');
const {color} = require('../config/json/config.json')
const user = require('../mongoDB/user.js');

exports.run = async (client, message, args) => {
    
    
    if(args[0] === 'list') {
        let botperm = await client.db.get(`botperm`);
        
        if(!botperm.includes(message.author.id)) return;
        
        user.findOne({ User: message.author.id }, async (err, data) => {
        
            let description = "";
            for(let i = 0; i < 20; i++) {
                description += `${i+1} - \`(${data.Tag}/${data.User})\`\n`
 }
        const list = new MessageEmbed()
        .setTitle(`**Lista: ${data.length}**`)
        .setDescription(description)
        .setColor(color)
       message.inlineReply(message.author, list)
        });
    }
    if(args[0] === 'deletar') {
        
        user.findOne({ User: message.author.id }, async (err, data) => {
        
            if(err) {
                message.channel.send(`Ocorreu um erro`)
                console.log(err)
            }
            
            if(!data) return message.inlineReply(`Você não tem uma conta para deletar, caso tenha usado esse comando primeiro, escreva novamente`)
            
        user.findOneAndDelete({ User: message.author.id }, async (err, data) => {
            if(err) {
                message.inlineReply(`Ocorreu um erro`)
                console.log(err)
            }
            await message.inlineReply(`Sua conta foi deletada da minha database, para adicionar dnv, basta escrever um comando meu`)
        })
    });
}
    let userUser = message.mentions.users.first() || (!isNaN(args[0])? await client.users.fetch(String(args[0])):message.author)
    
    user.findOne({ User: userUser.id }, async (err, data) => {
        if(err) {
            return message.inlineReply(`Ocorreu um erro`)
      console.log(err)
        }
            if(!data) return message.inlineReply(`O usuário \`(${userUser.tag}/${userUser.id})\` não está registrado em minha database`)
       
       let userData = await client.users.fetch(data.User);
        
        
        const embed = new MessageEmbed()
        .setAuthor(`<:emoji_17:840693502643011594> **|** Conta de ${data.Tag}`, userData.avatarURL())
.setDescription(`**Usuário:**\n\`${data.Tag}\`\n**ID:**\n\`${data.User}\`\n**Créditos:**\n\`${(data.Daily === null?0:data.Daily)}\``)
        .setColor(color)
       
        message.inlineReply(message.author, embed)
    });
}
exports.config = {
    name: "conta",
    aliases: ['account']
}