const {shards} = require('../config/json/config.json');

exports.run = async (client, message, args) => {
    try {
 let promise = [
client.shard.fetchClientValues('ws.ping')
];
Promise.all(promise)
.then(async results => {
let Ping = results[0].reduce((acc, totalPing) => acc + totalPing, 0);

let svPing = Date.now() - message.createdTimestamp
    
    
    let ping = await client.db.ping()
    message.inlineReply('Ping?').then(msg => {
    
    msg.edit(`🏓 **|** ${message.author} pong\n:satellite: **|** **Shards:**(${message.guild.shard.id}/0)\n:stopwatch: **|** **Latência da API:** \`${svPing}ms\`\n:zap: **|** **Ping:** \`${Ping}ms\`\n🌐 **|** **Ping da DataBase:**\n➥📖 **|** **read:** \`${ping.read}ms\`\n➥✏ **|** **write:** \`${ping.write}ms\`\n🌏 **|** **Ping da shard:** \`${client.ws.ping}ms\``)
        });
            })
            } catch (err) {
            console.log(err)
            
            let svPing = Date.now() - message.createdTimestamp
     let shardPing = `Ocorreu um erro com as shards :pensive:`
   
    
    let ping = await client.db.ping()
    message.inlineReply('Ping?').then(msg => {
    
    msg.edit(`🏓 **|** ${message.author} pong\n:satellite: **|** **Shards:**(${message.guild.shard.id}/0)\n:stopwatch: **|** **Latência da API:** \`${svPing}ms\`\n:zap: **|** **Ping:** \`${Ping}ms\`\n🌐 **|** **Ping da DataBase:**\n➥📖 **|** **read:** \`${ping.read}ms\`\n➥✏ **|** **write:** \`${ping.write}ms\`\n🌏 **|** **Ping da shard:** \`${shardPing}\``)
        });
    
    }
    }
exports.config = {
    name: 'ping',
    aliases: ['pingar']
}